using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class about : MonoBehaviour
{
   public void Back()
   {
      SceneManager.LoadSceneAsync(1);
   }
   public void BackF()
   {
      SceneManager.LoadSceneAsync(6);
   }
   public void BackB()
   {
      SceneManager.LoadSceneAsync(4);
   }
}
