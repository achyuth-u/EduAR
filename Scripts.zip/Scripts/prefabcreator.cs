using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.ARFoundation;

public class prefabcreator : MonoBehaviour
{
    [SerializeField] private GameObject heartprefab;
    [SerializeField] private Vector3 prefaboffset;

    private GameObject heart;
    private ARTrackedImageManager aRTrackedImageManager;

    private void OnEnable()
    {
        aRTrackedImageManager = gameObject.GetComponent<ARTrackedImageManager>();
        aRTrackedImageManager.trackedImagesChanged += OnImageChanged;
    }

    private void OnDisable()
    {
        aRTrackedImageManager.trackedImagesChanged -= OnImageChanged;
    }

    private void OnImageChanged(ARTrackedImagesChangedEventArgs obj)
{
    foreach (ARTrackedImage image in obj.added)
    {
        if (heart == null)
        {
            heart = Instantiate(heartprefab, image.transform);
            heart.transform.position += prefaboffset;
        }
    }
}

}
