using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR;
using UnityEngine.XR.ARFoundation;

public class IR : MonoBehaviour
{
    [SerializeField]
    private GameObject modelPrefab; // Assign your 3D model prefab in the Inspector

    private ARTrackedImageManager _arTrackedImageManager;
    private Dictionary<string, GameObject> spawnedModels = new Dictionary<string, GameObject>();

    private void Awake()
    {
        _arTrackedImageManager = FindObjectOfType<ARTrackedImageManager>();
    }

    public void OnEnable()
    {
        _arTrackedImageManager.trackedImagesChanged += OnImageChanged;
    }

    public void OnDisable()
    {
        _arTrackedImageManager.trackedImagesChanged -= OnImageChanged;
    }

    public void OnImageChanged(ARTrackedImagesChangedEventArgs args)
    {
        foreach (var trackedImage in args.added)
        {
            var modelName = trackedImage.referenceImage.name;
            GameObject model = Instantiate(modelPrefab, trackedImage.transform.position, Quaternion.identity);
            model.transform.SetParent(trackedImage.transform);
            
            // Scale the model to match the image size
            Vector3 imageSize = new Vector3(trackedImage.size.x, model.transform.localScale.y, trackedImage.size.y);
            model.transform.localScale = Vector3.Min(model.transform.localScale, imageSize);

            spawnedModels[modelName] = model;
        }

        foreach (var trackedImage in args.updated)
        {
            var modelName = trackedImage.referenceImage.name;
            if (spawnedModels.TryGetValue(modelName, out GameObject model))
            {
                model.transform.position = trackedImage.transform.position;
                model.transform.rotation = trackedImage.transform.rotation;
            }
        }

        foreach (var trackedImage in args.removed)
        {
            var modelName = trackedImage.referenceImage.name;
            if (spawnedModels.TryGetValue(modelName, out GameObject model))
            {
                Destroy(model);
                spawnedModels.Remove(modelName);
            }
        }
    }
}
