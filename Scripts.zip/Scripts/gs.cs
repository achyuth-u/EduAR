using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class gs : MonoBehaviour
{
   public void Getstarted()
   {
      SceneManager.LoadSceneAsync(1);
   }
}
