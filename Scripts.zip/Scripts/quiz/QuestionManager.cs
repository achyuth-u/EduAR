using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro; // Include the TextMeshPro namespace

public class QuestionManager : MonoBehaviour
{
    public TMP_Text questionText; // Change to TMP_Text
    public TMP_Text scoreText; // Change to TMP_Text
    public TMP_Text finalScore; // Change to TMP_Text
    public Button[] replyButtons;
    public QtsData qtsData; // Reference to the scriptable object
    public GameObject Right;
    public GameObject Wrong;
    public GameObject GameFinished;

    private int currentQuestion = 0;
    private static int score = 0;

    void Start()
    {
        SetQuestion(currentQuestion);
        Right.SetActive(false);
        Wrong.SetActive(false);
        GameFinished.SetActive(false);
    }

    void SetQuestion(int questionIndex)
    {
        questionText.text = qtsData.questions[questionIndex].questionText;

        // Remove previous listeners before adding new ones
        foreach (Button r in replyButtons)
        {
            r.onClick.RemoveAllListeners();
        }

        for (int i = 0; i < replyButtons.Length; i++)
        {
            replyButtons[i].GetComponentInChildren<TMP_Text>().text = qtsData.questions[questionIndex].replies[i];
            int replyIndex = i;
            replyButtons[i].onClick.AddListener(() => 
            {
                CheckReply(replyIndex);
            });
        }
    }

    void CheckReply(int replyIndex)
    {
        if (replyIndex == qtsData.questions[currentQuestion].correctReplyIndex)
        {
            score++;
            scoreText.text = score.ToString();

            // Enable Right reply panel
            Right.SetActive(true);

            // Set Active false for all reply buttons
            foreach (Button r in replyButtons)
            {
                r.interactable = false;
            }

            // Next Question
            StartCoroutine(Next());
        }
        else
        {
            // Wrong reply 
            Wrong.SetActive(true);

            // Set Active false for all reply buttons
            foreach (Button r in replyButtons)
            {
                r.interactable = false;
            }

            // Next Question 
            StartCoroutine(Next());
        }
    }

   IEnumerator Next()
{
    yield return new WaitForSeconds(2);

    currentQuestion++;

    if (currentQuestion < qtsData.questions.Length)
    {
        // Reset the UI and enable all reply buttons
        Reset();
    }
    else
    {
        // Game over
        GameFinished.SetActive(true);

        // Calculate the score percentage
        float scorePercentage = (float)score / qtsData.questions.Length;

        // Display the score percentage
        finalScore.text = "You scored " + (scorePercentage * 100).ToString("F0") + "%";

        // Display the appropriate message based on the score percentage
        if (scorePercentage < 0.5f)
        {
            finalScore.text += "\nBetter Luck Next Time";
        }
        else if (scorePercentage < 0.6f)
        {
            finalScore.text += "\nKeep Trying";
        }
        else if (scorePercentage < 0.7f)
        {
            finalScore.text += "\nGood Job";
        }
        else if (scorePercentage < 0.8f)
        {
            finalScore.text += "\nWell Done!";
        }
        else
        {
            finalScore.text += "\nYou're a genius!";
        }

        // Reset the score
        score = 0;
    }
}


    public void Reset()
    {
        // Hide both the "Right" and "Wrong" panels
        Right.SetActive(false);
        Wrong.SetActive(false);

        // Enable all reply buttons
        foreach (Button r in replyButtons)
        {
            r.interactable = true;
        }

        // Set the next question
        SetQuestion(currentQuestion);
    }
}

