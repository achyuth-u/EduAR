using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

public class MultipleImageTracker : MonoBehaviour
{
    private ARTrackedImageManager trackedImages;
    public GameObject[] ArPrefabs;

    List<GameObject> ARObjects = new List<GameObject>();

    void Awake()
    {
        trackedImages = GetComponent<ARTrackedImageManager>();
    }

    void OnEnable()
    {
        trackedImages.trackedImagesChanged += OnTrackedImagesChanged;
    }

    void OnDisable()
    {
        trackedImages.trackedImagesChanged -= OnTrackedImagesChanged;
    }

    // Event Handler
    private void OnTrackedImagesChanged(ARTrackedImagesChangedEventArgs eventArgs)
    {
        // Create or update objects based on image tracked
        foreach (var trackedImage in eventArgs.added)
        {
            InstantiateARObject(trackedImage);
        }

        foreach (var trackedImage in eventArgs.updated)
        {
            UpdateARObject(trackedImage);
        }
    }

    private void InstantiateARObject(ARTrackedImage trackedImage)
    {
        foreach (var arPrefab in ArPrefabs)
        {
            if (trackedImage.referenceImage.name == arPrefab.name)
            {
                var newPrefab = Instantiate(arPrefab, trackedImage.transform);
                newPrefab.name = arPrefab.name; // Ensure the prefab has the correct name for tracking
                ARObjects.Add(newPrefab);
            }
        }
    }

    private void UpdateARObject(ARTrackedImage trackedImage)
    {
        foreach (var arObject in ARObjects)
        {
            if (arObject.name == trackedImage.referenceImage.name)
            {
                arObject.SetActive(trackedImage.trackingState == TrackingState.Tracking);
                RotateARObject(arObject);
            }
        }
    }

    private void RotateARObject(GameObject arObject)
    {
        // Rotate object based on touch gesture
        if (Input.touchCount == 1)
        {
            Touch touch = Input.GetTouch(0);
            if (touch.phase == TouchPhase.Moved)
            {
                float rotationSpeed = 0.1f; // Adjust rotation speed as needed
                // Horizontal rotation
                float horizontalRotation = -touch.deltaPosition.x * rotationSpeed;
                // Vertical rotation
                float verticalRotation = touch.deltaPosition.y * rotationSpeed;
                // Apply rotation
                arObject.transform.Rotate(verticalRotation, horizontalRotation, 0f, Space.World);
            }
        }
    }
}
