using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class mm : MonoBehaviour
{
   public void Scan()
   {
      SceneManager.LoadSceneAsync(2);
   }
   public void Updates()
   {
      SceneManager.LoadSceneAsync(3);
   }
   public void About()
   {
      SceneManager.LoadSceneAsync(4);
   }
     public void quiz()
   {
      SceneManager.LoadSceneAsync(5);
   }
    public void Quit()
   {
      Application.Quit();
   }

}
