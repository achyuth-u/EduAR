using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TripleTap : MonoBehaviour
{
    private int tapCount;
    private float lastTapTime;
    private float tripleTapTime = 0.2f; // Time within which a tap should be considered as part of a triple tap

    public AudioClip soundClip; // Assign your AudioClip here
    private AudioSource audioSource;

    void Start()
    {
        // Initialize the AudioSource component
        audioSource = gameObject.AddComponent<AudioSource>();
        audioSource.clip = soundClip;
    }

    void Update()
    {
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);
            if (touch.phase == TouchPhase.Ended)
            {
                // Check if the tap is within the triple tap time window
                if (Time.time - lastTapTime < tripleTapTime)
                {
                    tapCount++;
                }
                else
                {
                    // Reset tap count if the tap is outside the triple tap time window
                    tapCount = 0;
                }

                lastTapTime = Time.time;

                // If there are three taps, play the audio
                if (tapCount == 3)
                {
                    PlayAudio();
                    tapCount = 0; // Reset tap count after playing the audio
                }
            }
        }
    }

    private void PlayAudio()
    {
        if (audioSource != null && !audioSource.isPlaying)
        {
            audioSource.Play();
        }
    }
}
