using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GestureControl : MonoBehaviour
{
    private Vector2 touchStart;
    private float initialScale;

    void Start()
    {
        initialScale = transform.localScale.x; // Assuming uniform scaling
    }

    void Update()
    {
        if (Input.touchCount == 1)
        {
            Touch touch = Input.GetTouch(0);

            if (touch.phase == TouchPhase.Moved)
            {
                // Increase the rotation speed here
                float rotationSpeed = 0.5f; // Adjust this value as needed
                float rotationAmount = -touch.deltaPosition.x * rotationSpeed * Time.deltaTime;
                transform.Rotate(0f, rotationAmount, 0f);

                // Debugging output
                Debug.Log("Rotating object by " + rotationAmount);
            }
        }
        else if (Input.touchCount == 2)
        {
            Touch touchZero = Input.GetTouch(0);
            Touch touchOne = Input.GetTouch(1);

            Vector2 touchZeroPrevPos = touchZero.position - touchZero.deltaPosition;
            Vector2 touchOnePrevPos = touchOne.position - touchOne.deltaPosition;

            float prevMagnitude = (touchZeroPrevPos - touchOnePrevPos).magnitude;
            float currentMagnitude = (touchZero.position - touchOne.position).magnitude;

            float difference = currentMagnitude - prevMagnitude;

            // Zoom based on the distance between the two touches
            float scaleChange = difference * 0.01f;
            float newScale = Mathf.Clamp(transform.localScale.x + scaleChange, initialScale, initialScale * 2);
            transform.localScale = new Vector3(newScale, newScale, newScale);
        }
    }
}
