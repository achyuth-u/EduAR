using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimatedObjectController : MonoBehaviour
{
    private ARTrackedImage trackedImage;

    void Start()
    {
        // Find the ARTrackedImage component in the parent hierarchy
        trackedImage = GetComponentInParent<ARTrackedImage>();

        // Ensure the object starts disabled until it's properly positioned
        gameObject.SetActive(false);
    }

    void Update()
    {
        // Check if the tracked image is being tracked
        if (trackedImage != null && trackedImage.trackingState == TrackingState.Tracking)
        {
            // Enable the object if it's not already active
            if (!gameObject.activeSelf)
            {
                gameObject.SetActive(true);
            }

            // Update the position and rotation of the object to match the tracked image
            transform.position = trackedImage.transform.position;
            transform.rotation = trackedImage.transform.rotation;
        }
        else
        {
            // Disable the object if the tracked image is lost or not tracking
            gameObject.SetActive(false);
        }
    }
}
