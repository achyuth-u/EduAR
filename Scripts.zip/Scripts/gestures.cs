using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ModelController : MonoBehaviour
{
    public AudioClip soundClip; // Assign your AudioClip here

    private AudioSource audioSource;
    private float rotationSpeed = 25f; // Reduced from 50f
    private float zoomSpeed = 5f; // Reduced from 10f

    void Start()
    {
        // Create an AudioSource component and configure it
        audioSource = gameObject.AddComponent<AudioSource>();
        audioSource.clip = soundClip;
        audioSource.loop = true; // Set the audio to loop
        audioSource.Play(); // Play the audio
    }

    void Update()
    {
        // Rotate the model
        if (Input.touchCount == 1)
        {
            Touch touch = Input.GetTouch(0);
            if (touch.phase == TouchPhase.Moved)
            {
                transform.Rotate(0f, -touch.deltaPosition.x * rotationSpeed * Time.deltaTime, 0f, Space.World);
            }
        }

        // Zoom in/out the model
        if (Input.touchCount == 2)
        {
            Touch touchZero = Input.GetTouch(0);
            Touch touchOne = Input.GetTouch(1);

            Vector2 touchZeroPrevPos = touchZero.position - touchZero.deltaPosition;
            Vector2 touchOnePrevPos = touchOne.position - touchOne.deltaPosition;

            float prevTouchDeltaMag = (touchZeroPrevPos - touchOnePrevPos).magnitude;
            float touchDeltaMag = (touchZero.position - touchOne.position).magnitude;

            float deltaMagnitudeDiff = prevTouchDeltaMag - touchDeltaMag;

            transform.localScale -= new Vector3(deltaMagnitudeDiff, deltaMagnitudeDiff, deltaMagnitudeDiff) * zoomSpeed * Time.deltaTime;
        }
    }
}
